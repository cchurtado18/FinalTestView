//
//  HomeViewController.swift
//  InterfazCarlos
//
//  Created by Oscar Alvarado on 3/9/24.
//

import UIKit

class HomeViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }


}
